<template>
	<view class="container">
		<!-- 搜索栏 -->
		<view class="search-bar">
			<input type="text" v-model="searchKeyword" placeholder="搜索竞赛" @confirm="handleSearch" />
			<button class="search-btn" @click="handleSearch">搜索</button>
		</view>

		<!-- 状态筛选 -->
		<view class="status-filter">
			<view 
				class="filter-item" 
				:class="{ active: currentStatus === status.value }"
				v-for="status in statusList" 
				:key="status.value"
				@click="handleStatusChange(status.value)"
			>
				{{ status.label }}
			</view>
		</view>

		<!-- 竞赛列表 -->
		<view class="competition-list">
			<view class="competition-item" v-for="(competition, index) in competitions" :key="index" @click="viewDetail(competition)">
				<view class="competition-content">
					<text class="competition-title">{{ competition.title }}</text>
					<view class="competition-info">
						<text class="competition-time">报名时间：{{ competition.signupTime }}</text>
						<text class="competition-status" :class="competition.status">{{ getStatusText(competition.status) }}</text>
					</view>
					<text class="competition-desc">{{ competition.description }}</text>
				</view>
				<text class="competition-arrow">></text>
			</view>
		</view>

		<!-- 加载更多 -->
		<view class="load-more" v-if="hasMore" @click="loadMore">
			<text>加载更多</text>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			searchKeyword: '',
			currentStatus: 'ALL',
			statusList: [
				{ label: '全部', value: 'ALL' },
				{ label: '未开始', value: 'NOT_STARTED' },
				{ label: '报名中', value: 'SIGNING_UP' },
				{ label: '进行中', value: 'IN_PROGRESS' },
				{ label: '已结束', value: 'ENDED' }
			],
			competitions: [],
			page: 1,
			pageSize: 10,
			hasMore: true
		}
	},
	onLoad() {
		this.loadCompetitions()
	},
	methods: {
		// 加载竞赛数据
		async loadCompetitions(reset = true) {
			if (reset) {
				this.page = 1
				this.competitions = []
			}
			
			try {
				const res = await uni.request({
					url: 'http://localhost:8080/api/competitions',
					method: 'GET',
					data: {
						page: this.page,
						pageSize: this.pageSize,
						keyword: this.searchKeyword,
						status: this.currentStatus === 'ALL' ? '' : this.currentStatus
					},
					header: {
						'Authorization': uni.getStorageSync('token')
					}
				})
				
				if (res.statusCode === 200) {
					const { data, total } = res.data
					this.competitions = [...this.competitions, ...data]
					this.hasMore = this.competitions.length < total
				}
			} catch (error) {
				console.error('加载竞赛失败:', error)
				uni.showToast({
					title: '加载竞赛失败',
					icon: 'none'
				})
			}
		},
		// 搜索
		handleSearch() {
			this.loadCompetitions(true)
		},
		// 状态筛选
		handleStatusChange(status) {
			this.currentStatus = status
			this.loadCompetitions(true)
		},
		// 查看详情
		viewDetail(competition) {
			uni.navigateTo({
				url: `/pages/competition/detail?id=${competition.id}`
			})
		},
		// 加载更多
		loadMore() {
			if (this.hasMore) {
				this.page++
				this.loadCompetitions(false)
			}
		},
		// 获取状态文本
		getStatusText(status) {
			const statusMap = {
				'NOT_STARTED': '未开始',
				'SIGNING_UP': '报名中',
				'IN_PROGRESS': '进行中',
				'ENDED': '已结束'
			}
			return statusMap[status] || status
		}
	}
}
</script>

<style lang="scss">
.container {
	padding: 20rpx;
}

.search-bar {
	display: flex;
	margin-bottom: 20rpx;
	
	input {
		flex: 1;
		height: 72rpx;
		background-color: #f5f5f5;
		border-radius: 36rpx;
		padding: 0 30rpx;
		font-size: 28rpx;
	}
	
	.search-btn {
		width: 120rpx;
		height: 72rpx;
		line-height: 72rpx;
		text-align: center;
		background-color: #1890ff;
		color: #fff;
		border-radius: 36rpx;
		margin-left: 20rpx;
		font-size: 28rpx;
	}
}

.status-filter {
	display: flex;
	margin-bottom: 20rpx;
	background-color: #fff;
	padding: 20rpx;
	border-radius: 12rpx;
	
	.filter-item {
		padding: 10rpx 20rpx;
		font-size: 28rpx;
		color: #666;
		margin-right: 20rpx;
		border-radius: 20rpx;
		
		&.active {
			background-color: #1890ff;
			color: #fff;
		}
	}
}

.competition-list {
	.competition-item {
		display: flex;
		justify-content: space-between;
		align-items: center;
		background-color: #fff;
		padding: 20rpx;
		margin-bottom: 20rpx;
		border-radius: 12rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
	}
	
	.competition-content {
		flex: 1;
	}
	
	.competition-title {
		font-size: 32rpx;
		color: #333;
		margin-bottom: 10rpx;
		display: block;
	}
	
	.competition-info {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 10rpx;
	}
	
	.competition-time {
		font-size: 24rpx;
		color: #999;
	}
	
	.competition-status {
		font-size: 24rpx;
		padding: 4rpx 12rpx;
		border-radius: 20rpx;
		
		&.NOT_STARTED {
			background-color: #e6f7ff;
			color: #1890ff;
		}
		
		&.SIGNING_UP {
			background-color: #f6ffed;
			color: #52c41a;
		}
		
		&.IN_PROGRESS {
			background-color: #fff7e6;
			color: #fa8c16;
		}
		
		&.ENDED {
			background-color: #f5f5f5;
			color: #999;
		}
	}
	
	.competition-desc {
		font-size: 26rpx;
		color: #666;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
	}
	
	.competition-arrow {
		color: #999;
		font-size: 28rpx;
		margin-left: 20rpx;
	}
}

.load-more {
	text-align: center;
	padding: 20rpx;
	color: #666;
	font-size: 28rpx;
}
</style> 