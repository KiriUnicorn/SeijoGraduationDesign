<template>
	<view class="container">
		<view class="login-box">
			<view class="title">竞赛管理系统</view>
			
			<!-- 角色选择 -->
			<view class="role-select">
				<view 
					class="role-item" 
					:class="{ active: currentRole === role.value }"
					v-for="role in roles" 
					:key="role.value"
					@click="handleRoleChange(role.value)"
				>
					{{ role.label }}
				</view>
			</view>
			
			<!-- 登录表单 -->
			<view class="login-form">
				<view class="input-item">
					<text class="label">邮箱</text>
					<input 
						type="text" 
						v-model="email" 
						placeholder="请输入邮箱" 
						@input="validateEmail"
					/>
				</view>
				<view class="input-item">
					<text class="label">密码</text>
					<input 
						:type="showPassword ? 'text' : 'password'" 
						v-model="password" 
						placeholder="请输入密码"
					/>
					<text class="eye-icon" @click="togglePassword">
						{{ showPassword ? '👁️' : '👁️‍🗨️' }}
					</text>
				</view>
				
				<!-- 拼图验证码 -->
				<view class="puzzle-captcha">
					<text class="label">拼图验证</text>
					<view class="puzzle-container" @touchstart="handleTouchStart" @touchmove="handleTouchMove" @touchend="handleTouchEnd">
						<image class="puzzle-bg" :src="captchaImage" mode="aspectFill"></image>
						<view 
							class="puzzle-piece" 
							:style="{ left: puzzlePosition + 'px' }"
						></view>
						<view class="puzzle-track">
							<view class="puzzle-slider" :style="{ left: puzzlePosition + 'px' }">
								<text class="slider-icon">→</text>
							</view>
						</view>
					</view>
				</view>
				
				<button class="login-btn" @click="handleLogin" :disabled="!isFormValid">登录</button>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			roles: [
				{ label: '学生', value: 'STUDENT' },
				{ label: '教师', value: 'TEACHER' },
				{ label: '管理员', value: 'ADMIN' }
			],
			currentRole: 'STUDENT',
			email: '',
			password: '',
			showPassword: false,
			captchaImage: '/static/captcha-bg.png',
			puzzlePosition: 0,
			isDragging: false,
			startX: 0,
			isFormValid: false
		}
	},
	methods: {
		// 切换角色
		handleRoleChange(role) {
			this.currentRole = role
		},
		// 切换密码显示
		togglePassword() {
			this.showPassword = !this.showPassword
		},
		// 验证邮箱
		validateEmail() {
			const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
			this.isFormValid = emailRegex.test(this.email) && 
				this.password.length >= 6 && 
				this.puzzlePosition > 0
		},
		// 处理触摸开始
		handleTouchStart(e) {
			this.isDragging = true
			this.startX = e.touches[0].clientX
		},
		// 处理触摸移动
		handleTouchMove(e) {
			if (!this.isDragging) return
			
			const currentX = e.touches[0].clientX
			const diff = currentX - this.startX
			const containerWidth = 300 // 容器宽度
			const maxPosition = containerWidth - 40 // 滑块宽度
			
			this.puzzlePosition = Math.max(0, Math.min(diff, maxPosition))
			this.validateEmail()
		},
		// 处理触摸结束
		handleTouchEnd() {
			this.isDragging = false
			// 验证拼图位置是否正确
			if (this.puzzlePosition > 0) {
				this.validateEmail()
			}
		},
		// 处理登录
		async handleLogin() {
			if (!this.isFormValid) return
			
			try {
				// 根据角色选择不同的登录API
				let loginUrl = ''
				switch (this.currentRole) {
					case 'STUDENT':
						loginUrl = 'http://localhost:8080/api/auth/student/login'
						break
					case 'TEACHER':
						loginUrl = 'http://localhost:8080/api/auth/teacher/login'
						break
					case 'ADMIN':
						loginUrl = 'http://localhost:8080/api/auth/admin/login'
						break
					default:
						throw new Error('无效的角色类型')
				}
				
				const res = await uni.request({
					url: loginUrl,
					method: 'POST',
					data: {
						email: this.email,
						password: this.password
					},
					header: {
						'Content-Type': 'application/json'
					}
				})
				
				if (res.statusCode === 200) {
					const { token, role } = res.data.data
					uni.setStorageSync('token', token)
					uni.setStorageSync('role', role)
					
					uni.showToast({
						title: '登录成功',
						icon: 'success',
						duration: 1500,
						success: () => {
							// 使用switchTab跳转到首页，这样可以保留tabBar
							setTimeout(() => {
								uni.switchTab({
									url: '/pages/index/index',
									success: () => {
										console.log('跳转成功')
									},
									fail: (err) => {
										console.error('跳转失败:', err)
									}
								})
							}, 1500)
						}
					})
				} else {
					uni.showToast({
						title: res.data.message || '登录失败',
						icon: 'none'
					})
				}
			} catch (error) {
				console.error('登录失败:', error)
				uni.showToast({
					title: '登录失败，请稍后重试',
					icon: 'none'
				})
			}
		}
	}
}
</script>

<style lang="scss">
.container {
	min-height: 100vh;
	background-color: #f5f5f5;
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 40rpx;
}

.login-box {
	width: 100%;
	background-color: #fff;
	border-radius: 20rpx;
	padding: 40rpx;
	box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.1);
}

.title {
	font-size: 40rpx;
	font-weight: bold;
	color: #333;
	text-align: center;
	margin-bottom: 40rpx;
}

.role-select {
	display: flex;
	justify-content: space-between;
	margin-bottom: 40rpx;
	
	.role-item {
		flex: 1;
		text-align: center;
		padding: 20rpx 0;
		font-size: 28rpx;
		color: #666;
		background-color: #f5f5f5;
		margin: 0 10rpx;
		border-radius: 10rpx;
		
		&:first-child {
			margin-left: 0;
		}
		
		&:last-child {
			margin-right: 0;
		}
		
		&.active {
			background-color: #1890ff;
			color: #fff;
		}
	}
}

.login-form {
	.input-item {
		position: relative;
		margin-bottom: 30rpx;
		
		.label {
			font-size: 28rpx;
			color: #333;
			margin-bottom: 10rpx;
			display: block;
		}
		
		input {
			width: 100%;
			height: 88rpx;
			background-color: #f5f5f5;
			border-radius: 44rpx;
			padding: 0 40rpx;
			font-size: 28rpx;
		}
		
		.eye-icon {
			position: absolute;
			right: 40rpx;
			top: 50%;
			transform: translateY(-50%);
			font-size: 40rpx;
		}
	}
}

.puzzle-captcha {
	margin-bottom: 40rpx;
	
	.label {
		font-size: 28rpx;
		color: #333;
		margin-bottom: 20rpx;
		display: block;
	}
	
	.puzzle-container {
		position: relative;
		width: 100%;
		height: 160rpx;
		background-color: #f5f5f5;
		border-radius: 10rpx;
		overflow: hidden;
		
		.puzzle-bg {
			width: 100%;
			height: 100%;
		}
		
		.puzzle-piece {
			position: absolute;
			width: 40rpx;
			height: 40rpx;
			background-color: rgba(24, 144, 255, 0.8);
			border-radius: 6rpx;
			top: 50%;
			transform: translateY(-50%);
		}
	}
	
	.puzzle-track {
		position: relative;
		width: 100%;
		height: 40rpx;
		background-color: #f5f5f5;
		border-radius: 20rpx;
		margin-top: 20rpx;
		
		.puzzle-slider {
			position: absolute;
			width: 40rpx;
			height: 40rpx;
			background-color: #1890ff;
			border-radius: 50%;
			top: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			
			.slider-icon {
				color: #fff;
				font-size: 24rpx;
			}
		}
	}
}

.login-btn {
	width: 100%;
	height: 88rpx;
	line-height: 88rpx;
	background-color: #1890ff;
	color: #fff;
	border-radius: 44rpx;
	font-size: 32rpx;
	
	&:disabled {
		background-color: #ccc;
	}
}
</style> 