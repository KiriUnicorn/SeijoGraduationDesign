<template>
	<view class="container">
		<!-- 公告区域 -->
		<view class="notice-section">
			<view class="section-header">
				<text class="title">最新公告</text>
				<text class="more" @click="goToAllNotices">查看全部</text>
			</view>
			<view class="notice-list">
				<view class="notice-item" v-for="(notice, index) in notices" :key="index" @click="viewNoticeDetail(notice)">
					<view class="notice-content">
						<text class="notice-title">{{ notice.title }}</text>
						<text class="notice-time">{{ notice.createTime }}</text>
					</view>
					<text class="notice-arrow">></text>
				</view>
			</view>
		</view>

		<!-- 竞赛区域 -->
		<view class="competition-section">
			<view class="section-header">
				<text class="title">最新竞赛</text>
				<text class="more" @click="goToAllCompetitions">查看全部</text>
			</view>
			<view class="competition-list">
				<view class="competition-item" v-for="(competition, index) in competitions" :key="index" @click="viewCompetitionDetail(competition)">
					<view class="competition-content">
						<text class="competition-title">{{ competition.title }}</text>
						<view class="competition-info">
							<text class="competition-time">报名时间：{{ competition.signupTime }}</text>
							<text class="competition-status" :class="competition.status">{{ getStatusText(competition.status) }}</text>
						</view>
					</view>
					<text class="competition-arrow">></text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				notices: [],
				competitions: []
			}
		},
		onLoad() {
			this.loadNotices()
			this.loadCompetitions()
		},
		methods: {
			// 加载公告数据
			async loadNotices() {
				try {
					const res = await uni.request({
						url: 'http://localhost:8080/api/notices/latest',
						method: 'GET',
						header: {
							'Authorization': uni.getStorageSync('token')
						}
					})
					if (res.statusCode === 200) {
						this.notices = res.data.data
					}
				} catch (error) {
					console.error('加载公告失败:', error)
					uni.showToast({
						title: '加载公告失败',
						icon: 'none'
					})
				}
			},
			// 加载竞赛数据
			async loadCompetitions() {
				try {
					const res = await uni.request({
						url: 'http://localhost:8080/api/competitions/latest',
						method: 'GET',
						header: {
							'Authorization': uni.getStorageSync('token')
						}
					})
					if (res.statusCode === 200) {
						this.competitions = res.data.data
					}
				} catch (error) {
					console.error('加载竞赛失败:', error)
					uni.showToast({
						title: '加载竞赛失败',
						icon: 'none'
					})
				}
			},
			// 查看公告详情
			viewNoticeDetail(notice) {
				uni.navigateTo({
					url: `/pages/notice/detail?id=${notice.id}`
				})
			},
			// 查看竞赛详情
			viewCompetitionDetail(competition) {
				uni.navigateTo({
					url: `/pages/competition/detail?id=${competition.id}`
				})
			},
			// 跳转到全部公告
			goToAllNotices() {
				uni.navigateTo({
					url: '/pages/notice/list'
				})
			},
			// 跳转到全部竞赛
			goToAllCompetitions() {
				uni.navigateTo({
					url: '/pages/competition/list'
				})
			},
			// 获取竞赛状态文本
			getStatusText(status) {
				const statusMap = {
					'NOT_STARTED': '未开始',
					'SIGNING_UP': '报名中',
					'IN_PROGRESS': '进行中',
					'ENDED': '已结束'
				}
				return statusMap[status] || status
			}
		}
	}
</script>

<style lang="scss">
	.container {
		padding: 20rpx;
	}

	.section-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 20rpx;
		
		.title {
			font-size: 32rpx;
			font-weight: bold;
			color: #333;
		}
		
		.more {
			font-size: 28rpx;
			color: #666;
		}
	}

	.notice-section, .competition-section {
		background-color: #fff;
		border-radius: 12rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
	}

	.notice-item, .competition-item {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 0;
		border-bottom: 1rpx solid #eee;
		
		&:last-child {
			border-bottom: none;
		}
	}

	.notice-content, .competition-content {
		flex: 1;
	}

	.notice-title, .competition-title {
		font-size: 28rpx;
		color: #333;
		margin-bottom: 10rpx;
		display: block;
	}

	.notice-time {
		font-size: 24rpx;
		color: #999;
	}

	.competition-info {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-top: 10rpx;
	}

	.competition-time {
		font-size: 24rpx;
		color: #999;
	}

	.competition-status {
		font-size: 24rpx;
		padding: 4rpx 12rpx;
		border-radius: 20rpx;
		
		&.NOT_STARTED {
			background-color: #e6f7ff;
			color: #1890ff;
		}
		
		&.SIGNING_UP {
			background-color: #f6ffed;
			color: #52c41a;
		}
		
		&.IN_PROGRESS {
			background-color: #fff7e6;
			color: #fa8c16;
		}
		
		&.ENDED {
			background-color: #f5f5f5;
			color: #999;
		}
	}

	.notice-arrow, .competition-arrow {
		color: #999;
		font-size: 28rpx;
		margin-left: 20rpx;
	}
</style>
