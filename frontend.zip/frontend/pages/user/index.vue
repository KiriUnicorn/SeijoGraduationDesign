<template>
	<view class="container">
		<!-- 用户信息 -->
		<view class="user-info">
			<view class="avatar">
				<image :src="userInfo.avatar || '/static/default-avatar.png'" mode="aspectFill"></image>
			</view>
			<view class="info">
				<text class="username">{{ userInfo.username }}</text>
				<text class="role">{{ getRoleText(userInfo.role) }}</text>
			</view>
		</view>

		<!-- 功能菜单 -->
		<view class="menu-list">
			<view class="menu-item" @click="goToMyCompetitions">
				<text class="menu-icon">📋</text>
				<text class="menu-text">我的竞赛</text>
				<text class="menu-arrow">></text>
			</view>
			<view class="menu-item" @click="goToMyTeams">
				<text class="menu-icon">👥</text>
				<text class="menu-text">我的团队</text>
				<text class="menu-arrow">></text>
			</view>
			<view class="menu-item" @click="goToSettings">
				<text class="menu-icon">⚙️</text>
				<text class="menu-text">设置</text>
				<text class="menu-arrow">></text>
			</view>
		</view>

		<!-- 退出登录 -->
		<button class="logout-btn" @click="handleLogout">退出登录</button>
	</view>
</template>

<script>
export default {
	data() {
		return {
			userInfo: {
				username: '',
				role: '',
				avatar: ''
			}
		}
	},
	onLoad() {
		this.loadUserInfo()
	},
	methods: {
		// 加载用户信息
		async loadUserInfo() {
			try {
				const res = await uni.request({
					url: 'http://localhost:8080/api/user/info',
					method: 'GET',
					header: {
						'Authorization': uni.getStorageSync('token')
					}
				})
				
				if (res.statusCode === 200) {
					this.userInfo = res.data.data
				}
			} catch (error) {
				console.error('加载用户信息失败:', error)
				uni.showToast({
					title: '加载用户信息失败',
					icon: 'none'
				})
			}
		},
		// 获取角色文本
		getRoleText(role) {
			const roleMap = {
				'ADMIN': '管理员',
				'TEACHER': '教师',
				'STUDENT': '学生'
			}
			return roleMap[role] || role
		},
		// 跳转到我的竞赛
		goToMyCompetitions() {
			uni.navigateTo({
				url: '/pages/user/competitions'
			})
		},
		// 跳转到我的团队
		goToMyTeams() {
			uni.navigateTo({
				url: '/pages/user/teams'
			})
		},
		// 跳转到设置
		goToSettings() {
			uni.navigateTo({
				url: '/pages/user/settings'
			})
		},
		// 退出登录
		handleLogout() {
			uni.showModal({
				title: '提示',
				content: '确定要退出登录吗？',
				success: (res) => {
					if (res.confirm) {
						uni.removeStorageSync('token')
						uni.removeStorageSync('role')
						uni.reLaunch({
							url: '/pages/login/index'
						})
					}
				}
			})
		}
	}
}
</script>

<style lang="scss">
.container {
	padding: 20rpx;
}

.user-info {
	display: flex;
	align-items: center;
	background-color: #fff;
	padding: 40rpx;
	border-radius: 12rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
	
	.avatar {
		width: 120rpx;
		height: 120rpx;
		border-radius: 60rpx;
		overflow: hidden;
		margin-right: 30rpx;
		
		image {
			width: 100%;
			height: 100%;
		}
	}
	
	.info {
		flex: 1;
		
		.username {
			font-size: 36rpx;
			color: #333;
			font-weight: bold;
			margin-bottom: 10rpx;
			display: block;
		}
		
		.role {
			font-size: 28rpx;
			color: #666;
		}
	}
}

.menu-list {
	background-color: #fff;
	border-radius: 12rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
	
	.menu-item {
		display: flex;
		align-items: center;
		padding: 30rpx;
		border-bottom: 1rpx solid #eee;
		
		&:last-child {
			border-bottom: none;
		}
		
		.menu-icon {
			font-size: 40rpx;
			margin-right: 20rpx;
		}
		
		.menu-text {
			flex: 1;
			font-size: 30rpx;
			color: #333;
		}
		
		.menu-arrow {
			color: #999;
			font-size: 28rpx;
		}
	}
}

.logout-btn {
	width: 100%;
	height: 88rpx;
	line-height: 88rpx;
	background-color: #ff4d4f;
	color: #fff;
	border-radius: 44rpx;
	font-size: 32rpx;
	margin-top: 40rpx;
}
</style> 