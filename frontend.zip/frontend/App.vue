<template>
	<view>
		<router-view></router-view>
	</view>
</template>

<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
			// 检查登录状态
			this.checkLoginStatus()
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		methods: {
			checkLoginStatus() {
				const token = uni.getStorageSync('token')
				const role = uni.getStorageSync('role')
				const currentPage = getCurrentPages()
				const currentRoute = currentPage[currentPage.length - 1]?.route
				
				// 如果未登录且不在登录页面，跳转到登录页
				if (!token && currentRoute !== 'pages/login/index') {
					uni.navigateTo({
						url: '/pages/login/index'
					})
				}
			}
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	page {
		background-color: #f5f5f5;
	}
</style>
